#include "header.h"

/* number of reserved words */
#define norw 15

/* maximum integer value */
#define imax 32767

/* maximum number of chars for idents */
#define cmax 11

/* maximum depth of block nesting */
#define nestmax 5

/* maximum length of strings */
#define strmax 256

/*Global symbol table for ease of use*/
symTable symbol_table[MAX_SYMBOL_TABLE_SIZE] = {0};
Token currentToken;
int symTablePos = 0, tokenTablePos = 0;
//Various
instruction MCode[MAX_CODE_LENGTH];
int MCodePos = 0, currentM = 0, lexiLevel = 0;
int column = 0, row = 1;
int counted = 0, numProcedures = 0;
int varLevel = 0, constLevel = 0, varNum = 0, constNum = 0;
char currentProc[identMax];

/*Function prototypes*/
void block(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int codeCounter, int lexiLevel);
void statement(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel);
void condition(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel);
void expression(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel);
void term(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel);
void factor(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel);
void emit(FILE* error, FILE* mCode, int op, int l, int m);
void voidSyms(int level);
int searchSym(char *name, int level);
void addSymTable(int kind, Token t, int L, int M, int num);
void readToken(FILE* input, FILE* error);
void printMCode(int flag, FILE* mCode);

int parse(int flag1, int flag2)
{

    FILE* input;
    FILE* mCode;
    FILE* error;

    input = fopen("lexemelist.txt", "r");
    mCode = fopen("pmasm.txt", "w");
    if(mCode == NULL)
        fprintf(error, "Error: Missing mcode.txt file");
    error = fopen("syntaxcheck.txt", "w");

    int symbolCounter = 0;
    int codeCounter = 0;
    int lexiLevel = 0;
    int listCounter = 0;

    readToken(input, error);

    /*Parses through block of code*/
    block(input, mCode, error, symbolCounter, codeCounter, lexiLevel);

    readToken(input, error);
    int tokenValue = atoi(currentToken.name);

    /*Checks if period is at the end*/
    if (tokenValue!= periodsym)
    {
        fprintf(error, "Error: No period at end of block");
        exit(0);
    }
    fprintf(error, "Program is syntactically correct.");
    fclose(error);

    //Print out symbol table if console command is inputted
    if(flag2)
    {
        int i;
        printf("\nSymbol Table:\nKind       Name  L Pos Val\n");
        for(i=0; i<symTablePos;i++)
            {
            printf("%4d %10s %2d %3d %3d\n",symbol_table[i].kind, symbol_table[i].name, symbol_table[i].level, symbol_table[i].addr, symbol_table[i].val);
            }
        printf("\n");
    }

    printMCode(flag1, mCode);
    fclose(input);
    fclose(mCode);
    return 1;
}

/*Function to parse through blocks*/
void block(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int codeCounter, int lexiLevel)
{
    counted = 0;
    int tempBlockPos = MCodePos, temPos;
    currentM = 0;

    //Print out the first message to start
    emit(error, mCode, 7, 0, 0);

    int tokenValue = atoi(currentToken.name);
    do
    {
        switch(tokenValue)
        {
        case constsym:
                ;
            Token tempT = currentToken;
            do
            {
                /*Variable to store value of symbol if it already exists in this level*/
                int levelValue = 0;
                readToken(input, error);
                tokenValue = atoi(currentToken.name);
                if (tokenValue != identsym)
                {
                    fprintf(error, "Error: Expected identifier after constant declaration.");
                    exit(0);
                }

                readToken(input, error);
                levelValue = searchSym(currentToken.name, lexiLevel);
                if(levelValue != -1 && symbol_table[levelValue].level == lexiLevel)
                {
                    fprintf(error, "Error: Identifier name declared twice.");
                    exit(0);
                }

                strcpy(tempT.name, currentToken.name);

                /*Check if there is an equal sign*/
                readToken(input, error);
                tokenValue = atoi(currentToken.name);
                if (tokenValue != eqlsym)
                {
                    fprintf(error, "Error: Expected = after identifier declaration.");
                    exit(0);
                }

                /*Check if const was assigned a numeric value*/
                readToken(input, error);
                tokenValue = atoi(currentToken.name);
                if (tokenValue != numbersym)
                {
                    fprintf(error, "Error: Expected numeric value for constants.");
                    exit(0);
                }

                /*If so, read in the entire value*/
                else
                {
                     if(tokenValue > imax)
                        {
                            fprintf(error, "Error: Numeric value greater than 32767.");
                            exit(0);
                        }
                        else
                        {
                            readToken(input, error);
                            addSymTable(1, tempT, constLevel, -5, currentToken.type);
                        }
                }
            }
            while(tokenValue == commasym);

            /*Check if semicolon is at end of statement*/
            readToken(input, error);
            tokenValue = atoi(currentToken.name);
            if(tokenValue != semicolonsym)
            {
                fprintf(error, "Error: Expected ; after constant declaration.");
                exit(0);
            }

            readToken(input, error);
            tokenValue = atoi(currentToken.name);
            counted++;
            temPos = currentM;
            break;

        case varsym:
            ;
            int levelValue = 0;
            varLevel = lexiLevel;
             //Keep pulling in new variables and adding to symbolTable for unique slots until no more commas
             do
             {
                readToken(input, error);
                tokenValue = atoi(currentToken.name);

                if (tokenValue != identsym)
                {
                    fprintf(error, "Error: Expected identifier after variable declaration.");
                    exit(0);
                }

                //Read in identifier name
                readToken(input, error);

                //Check if identifier exists already
                levelValue = searchSym(currentToken.name, lexiLevel);
                if(levelValue != -1 && symbol_table[levelValue].level == lexiLevel)
                {
                    fprintf(error, "Error: Identifier name declared twice.");
                    exit(0);
                }
                addSymTable(2, currentToken, lexiLevel, currentM+4, 0);

                //Checks if comma follows and continues looping if so
                readToken(input, error);
                tokenValue = atoi(currentToken.name);
             }
             while(tokenValue == commasym);

            /*Check if semicolon is at end of statement*/
            if(tokenValue != semicolonsym)
            {
                fprintf(error, "Error: Expected ; after variable declaration.");
                exit(0);
            }

            counted++;
            temPos = currentM;
            //Move on to next input
            readToken(input, error);
            tokenValue = atoi(currentToken.name);
             break;

        case procsym:
            do
            {
                numProcedures++;
                readToken(input, error);
                tokenValue = atoi(currentToken.name);

                if (tokenValue != identsym)
                {
                    fprintf(error, "Error: Expected identifier after procedure declaration.");
                    exit(0);
                }

                //Read in the name of the procedure
                readToken(input, error);
                strcpy(currentProc, currentToken.name);

                addSymTable(3, currentToken, lexiLevel, MCodePos, -1);
                lexiLevel++;
                if(lexiLevel > MAX_LEXI_LEVELS)
                {
                    fprintf(error, "Compiler has run out of memory. Exceeded max lexi levels");
                    exit(0);
                }
                numProcedures++;
                varNum = 0;

                /*Check if semicolon is at end of statement*/
                readToken(input, error);
                tokenValue = atoi(currentToken.name);
                if(tokenValue != semicolonsym)
                {
                    fprintf(error, "Error: Expected ; after procedure declaration.");
                    exit(0);
                }

                /*Check interior of procedure*/
                readToken(input, error);
                tokenValue = atoi(currentToken.name);
                block(input, mCode, error, symbolCounter, codeCounter, lexiLevel);
                lexiLevel--;

                tokenValue = atoi(currentToken.name);
                if(tokenValue != semicolonsym)
                {
                    fprintf(error, "Error: Expected ; after procedure declaration.");
                    exit(0);
                }
                strcpy(currentProc, " ");
                readToken(input, error);
            }
            while(tokenValue == procsym);

            MCode[tempBlockPos].m = MCodePos;
            break;
            }

    }while ((currentToken.type==constsym)||(currentToken.type==varsym)||(currentToken.type==procsym));
    emit(error, mCode, 6, 0, temPos + 4);
    statement(input, mCode, error, symbolCounter, lexiLevel);
    if(currentToken.type != periodsym && currentToken.type == semicolonsym)
    {
        //Return from procedure
        emit(error, mCode, 2, 0, 0);
        voidSyms(lexiLevel);
    }
    else
        emit(error, mCode, 9, 0, 2);
}

void statement(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel)
{
    int symPos, identPos, tempBPos, temPos, temPos2;

    int tokenValue = atoi(currentToken.name);

    switch(tokenValue)
    {
    /*Identsym case*/
    case identsym:
        //Read in name of identifier
        readToken(input, error);

        //If reading in int declaration, skip ahead of int and identsym declaration
        if(strcmp(currentToken.name, "int")==0)
            {
                readToken(input, error);
                readToken(input, error);
            }

        symPos = searchSym(currentToken.name, lexiLevel);

        if(symPos == -1)
        {
            fprintf(error, "Error: Unidentified variable found.");
            exit(0);
        }
        else if (symbol_table[symPos].kind == 1)
        {
            fprintf(error, "Assignment to const/proc not valid.");
            exit(0);
        }

        identPos = symbol_table[symPos].addr;

        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        if(tokenValue != becomesym)
        {
            fprintf(error, "Error: expected become after identifier");
            exit(0);
        }
        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        expression(input, mCode, error, symbolCounter, lexiLevel);
        emit(error, mCode, 4, lexiLevel-symbol_table[symPos].level, identPos);
        break;

    /*Callsym case*/
    case callsym:
        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        if(tokenValue != identsym)
        {
            fprintf(error, "Error: identifier expected after call");
            exit(0);
        }

        readToken(input, error);
        symPos = searchSym(currentToken.name, lexiLevel);
        if(symPos == -1)
        {
            fprintf(error, "Error: Unidentified variable found in call.");
            exit(0);
        }
        else if (symbol_table[symPos].kind == 1)
        {
            fprintf(error, "Assignment to const/proc not valid in call.");
            exit(0);
        }

        readToken(input, error);
        tokenValue = atoi(currentToken.name);

        emit(error, mCode, 5, lexiLevel, symbol_table[symPos].addr);
        break;

    /*Beginsym case*/
    case beginsym:
        readToken(input, error);
        statement(input, mCode, error, symbolCounter, lexiLevel);
        /*While in the begin statement, keep going until semicolon is reached*/
        tokenValue = atoi(currentToken.name);
        while(tokenValue == semicolonsym)
        {
            readToken(input, error);
            tokenValue = atoi(currentToken.name);
            statement(input, mCode, error, symbolCounter, lexiLevel);
            tokenValue = atoi(currentToken.name);
        }

        if(tokenValue != endsym)
        {
            fprintf(error, "Error: Expected end statement");
            exit(0);
        }
        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        break;

    case ifsym:
        readToken(input, error);
        condition(input, mCode, error, symbolCounter,lexiLevel);
        tokenValue = atoi(currentToken.name);
        if(tokenValue != thensym)
        {
            fprintf(error, "Error: Expected then statement");
            exit(0);
        }
        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        tempBPos = MCodePos;

        emit(error, mCode, 8, 0, 0);
        statement(input, mCode, error, symbolCounter, lexiLevel);
        MCode[tempBPos].m = MCodePos;

        readToken(input, error);
        tokenValue = atoi(currentToken.name);

        if(tokenValue != elsesym)
        {
            tokenTablePos--;
            tokenTablePos--;
            currentToken.type = tokenList[tokenTablePos].type;
            strcpy(currentToken.name, tokenList[tokenTablePos].name);
            tokenValue = atoi(currentToken.name);
            while(tokenValue == newlinesym)
            {
                tokenTablePos--;
                currentToken.type = tokenList[tokenTablePos].type;
                strcpy(currentToken.name, tokenList[tokenTablePos].name);
            }
            column--;
        }
        tokenValue = atoi(currentToken.name);
        if(tokenValue == elsesym)
        {
            MCode[tempBPos].m = MCodePos+1;
            tempBPos = MCodePos;

            emit(error, mCode, 7, 0, 0);
            readToken(input, error);
            statement(input, error, mCode, symbolCounter, lexiLevel);
            MCode[tempBPos].m = MCodePos;
        }
        tokenValue = atoi(currentToken.name);
        break;

    case whilesym:
        temPos = MCodePos;

        readToken(input, error);
        condition(input, mCode, error, symbolCounter, lexiLevel);
        temPos2 = MCodePos;

        emit(error, mCode, 8, 0, 0);

        tokenValue = atoi(currentToken.name);
        if(tokenValue != dosym)
        {
            fprintf(error, "Error: Expected do statement to follow while declaration");
            exit(0);
        }

        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        statement(input, mCode, error, symbolCounter, lexiLevel);

        emit(error, mCode, 7, 0, temPos);
        MCode[temPos2].m = MCodePos;
        break;
    }

}

void condition(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel)
{
    int tokenValue;
    tokenValue = atoi(currentToken.name);
    int thisOp;

    if (tokenValue == oddsym)
    {
        emit(error, mCode, 2, 0, 6);
        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        expression(input, mCode, error, symbolCounter, lexiLevel);
    }
    else
    {
        expression(input, mCode, error, symbolCounter, lexiLevel);

        switch (currentToken.type)
        {
            case eqlsym:
                thisOp = 8;
                break;

            case neqsym:
                thisOp = 9;
                break;

            case lessym:
                thisOp = 10;
                break;

            case leqsym:
                thisOp = 11;
                break;

            case gtrsym:
                thisOp = 12;
                break;

            case geqsym:
                thisOp = 13;
                break;

            default:
                fprintf(error, "Error: Relational operation expected.");
                exit(0);
                break;
        }

        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        expression(input, mCode, error, symbolCounter, lexiLevel);
        emit(error, input, 2, 0, thisOp);
    }
}

void expression(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel)
{
    int thisOp;

    if(currentToken.type == plussym || currentToken.type == minussym)
    {
        thisOp = currentToken.type;
        if(thisOp == minussym)
        {
            readToken(input, error);
            term(input, mCode, error, symbolCounter, lexiLevel);
            emit(error, mCode, 2, 0, 1);
        }
    }
    else
    {
        term(input, mCode, error, symbolCounter, lexiLevel);
    }

    while(currentToken.type == plussym || currentToken.type == minussym)
    {
        thisOp = currentToken.type;
        readToken(input, error);
        term(input, mCode, error, symbolCounter, lexiLevel);

        if(thisOp == plussym)
            emit(error, mCode, 2, 0, 2);
        else
            emit(error, mCode, 2, 0, 3);
    }
}

void term(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel)
{
    int thisOp;
    factor(input, mCode, error, symbolCounter, lexiLevel);

    while(currentToken.type == multsym || currentToken.type == slashsym)
    {
        thisOp = currentToken.type;
        readToken(input, error);
        factor(input, mCode, error, symbolCounter, lexiLevel);

        if(thisOp == multsym)
            emit(error, mCode, 2, 0, 4);
        else
            emit(error, mCode, 2, 0, 5);
    }
}

void factor(FILE* input, FILE* mCode, FILE* error, int symbolCounter, int lexiLevel)
{
    int symPos;

    int tokenValue = atoi(currentToken.name);

    if(tokenValue == identsym)
    {
        //Read in name
        readToken(input, error);
        symPos = searchSym(currentToken.name, lexiLevel);

        if(symPos == -1)
        {
            fprintf(error, "Error: Unidentified variable found.");
            exit(0);
        }

        if(symbol_table[symPos].kind == 1)
            emit(error, mCode, 1, 0, symbol_table[symPos].val);
        else
            emit(error, mCode, 3, lexiLevel-symbol_table[symPos].level, symbol_table[symPos].addr);

        readToken(input, error);
        tokenValue = atoi(currentToken.name);
    }
    else if (tokenValue == numbersym)
    {
        readToken(input, error);

        emit(error, mCode, 1, 0, atoi(currentToken.name));

        readToken(input, error);
        tokenValue = atoi(currentToken.name);

    }
    else if (tokenValue == lparentsym)
    {
        readToken(input, error);
        tokenValue = atoi(currentToken.name);
        expression(input, mCode, error, symbolCounter, lexiLevel);
        tokenValue = atoi(currentToken.name);
        if(tokenValue != rparentsym)
        {
            fprintf(error, "Error: Expected right parenthesis");
            exit(0);
        }

        readToken(input, error);
        tokenValue = atoi(currentToken.name);
    }
    else
    {
        fprintf(error, "Error: Unknown symbol in math expression");
        exit(0);
    }
}

/*Function to produce machine code from parsed tokens*/
void emit(FILE* error, FILE* mCode, int op, int l, int m)
{
    if(MCodePos > MAX_CODE_LENGTH)
    {
        fprintf(error, "Error: Code length exceeds 500.");
    }
    else
    {
        fprintf(mCode, "%d %d %d ", op, l, m);
    }
}

void readToken(FILE* input, FILE* error)
{
    fscanf(input, "%s", currentToken.name);
    currentToken.type = atoi(currentToken.name);
}

void voidSyms(int level)
{
    int i;
    for(i=symTablePos-1; i >= 0; i--)
    {
        if(symbol_table[i].level == level && symbol_table[i].kind != 3 && symbol_table[i].addr != -1)
        {
            symbol_table[i].addr = -1;
        }
    }
}

/*Find a variable in the symbol table*/
int searchSym(char *name, int level)
{
    int i;
    while(level != -1)
    {
        for(i=symTablePos-1; i >= 0; i--)
        {
            if((strcmp(name,symbol_table[i].name) == 0) && (symbol_table[i].addr != -1) && (symbol_table[i].level == level))
            {
                return i;
            }
        }
        level--;
    }
    /*If not found, return -1*/
    return -1;
}

/*Add to symbol table*/
void addSymTable(int kind, Token t, int L, int M, int num)
{
    symbol_table[symTablePos].kind = kind;
    strcpy(symbol_table[symTablePos].name,t.name);
    symbol_table[symTablePos].level = L;
    symbol_table[symTablePos].addr = M;
    if(kind == 1)
        symbol_table[symTablePos].val = num;
    else if (kind == 2)
        currentM++;
    else if (kind == 3)
    {
        procedures[procPos][0] = M;
        procedures[procPos][1] = L+1;
        procPos++;
    }

    symTablePos++;
}

//Print the MCode to the screen if console command was inputted
void printMCode(int flag, FILE* mCode)
{
    char c;

    if(flag)
    {
        printf("\nGenerated Machine Code\n");
        c = fgetc(mCode);
        while(c != EOF){
            printf("%c",c);
            c = fgetc(mCode);
        }
        printf("\n\n");
    }
    fclose(mCode);
}
