#include "Parser.h"
#include "lexicalAnalyzer.h"
#include "VMAssignment.h"
#include "Header.h"

int main(int argc, char *argv[])
{
    int l=0,a=0,v=0,i=0,s=0;


    if(argc != 0)
    {
        for(i=1; i<argc; i++)
            {
            //print token list
            if(strcmp(argv[i], "-l") == 0)
                l = 1;
            //print assembly code
            else if(strcmp(argv[i], "-a") == 0)
                a = 1;
            //print virtual machine exec. trace
            else if(strcmp(argv[i], "-v") == 0)
                v = 1;
            //print symbol table. "hidden"
            else if(strcmp(argv[i], "-s") == 0)
                s = 1;
            }
    }
    scan(l);
    parse(a,s);
    vm(v);
    return 0;
}
