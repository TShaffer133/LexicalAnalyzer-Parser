#include "Header.h"

void InterpretOp(instruction instruct, int* basePointer, int* stackPointer, int* programCounter, int* currentLevel,
                 int *lexiLevel, FILE* fWrite, int* halt);
void InterpretOPR(instruction instruct, int* basePointer, int* stackPointer, int* programCounter, int* currentLevel,
                 int *lexiLevel, FILE* fWrite);
void printInterpreted(instruction *code, FILE* fWrite, int codeLength);
void printStack(char* instruct, FILE* fWrite, int* basePointer, int* stackPointer, int* oldProgramCounter, int* newProgramCounter, int* currentLevel, int* lexiLevel,
                 int l, int m);

int stack[MAX_STACK_HEIGHT];

void vm(int flag)
{
	/*Get the File Readers/Writers Ready*/
	FILE *fRead;
	FILE *fWrite;
	fRead = fopen("pmasm.txt", "r");
	fWrite = fopen("stacktrace.txt", "w");

    /*Initialize registers*/
    int basePointer = 1;
    int stackPointer = 0;
    int programCounter = 0;
    int currentLevel = 0;
    instruction instructionRegister;

    /*Initialize storage for lexigraphical levels.
    Initialized to -1 to ensure that activation records are not accidentally printed. Unused levels will always be -1*/
    int lexiLevel[MAX_LEXI_LEVELS] = {-1, -1, -1};

	/*Initialize code memory storage*/
	instruction code[MAX_CODE_LENGTH];
	int i = 0;
	while (fscanf(fRead, "%d %d %d", &code[i].op, &code[i].l, &code[i].m) == 3)
	{
		i++;
	}

	/*Keep actual code length somewhere for ease of reference*/
	int codeLength = i;

	/*Print out first portion of stack trace*/
	printInterpreted(code, fWrite, codeLength);

    fprintf(fWrite, "Line\tOP\tL\tM\tPC\tBP\tSP\tSTACK\n");
    /*Boolean to determine if we need to halt*/
	int halt = 0;
	while(halt != 1)
    {
        InterpretOp(code[programCounter], &basePointer, &stackPointer, &programCounter, &currentLevel, lexiLevel, fWrite, &halt);
    }

    //Compiler command to print out execution trace
    if(flag)
    {
        char c;
            printf("\nGenerated stack trace\n");
            c = fgetc(fWrite);
            while(c != EOF){
                printf("%c",c);
                c = fgetc(fWrite);
            }
            printf("\n\n");
    }

	fclose(fRead);
	fclose(fWrite);
}

/*Reads in OpCode from instruction and performs the appropriate operation*/
void InterpretOp(instruction instruct, int* basePointer, int* stackPointer, int* programCounter, int* currentLevel,
                 int *lexiLevel, FILE* fWrite, int* halt)
{
    char* instructionName;
    int pc = *programCounter;
    pc = pc+1;

    switch(instruct.op)
    {
    /*Push m onto stack, LIT*/
    case 1:
        instructionName = "LIT";
        *stackPointer += 1;
        stack[*stackPointer] = instruct.m;
        printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
        *programCounter += 1;
        break;

    /*Perform operation with data on top of stack, OPR*/
    case 2:
        InterpretOPR(instruct, basePointer, stackPointer, programCounter, currentLevel, lexiLevel, fWrite);
        break;

    /*Load value into top of stack L levels down at offset M, LOD*/
    case 3:
        instructionName = "LOD";
        *stackPointer += 1;
        stack[*stackPointer] = stack[base(instruct.l, basePointer)+instruct.m];
        printStack(instructionName, fWrite,  basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
        *programCounter += 1;
        break;

    /*Store value at top of stack L level down at offset M, STO*/
    case 4:
        instructionName = "STO";
        stack[base(instruct.l, basePointer)+instruct.m] = stack[*stackPointer];
        *stackPointer -= 1;
        printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
        *programCounter += 1;
        break;

    /*Call procedure at index m, generate new activation record and pc = m, CAL*/
    case 5:
        instructionName = "CAL";
        //Store current position to print out activation record || later
        lexiLevel[*currentLevel] = *stackPointer;
        //Increment current level by 1
        *currentLevel = *currentLevel+1;
        stack[*stackPointer+1] = 0;
        stack[*stackPointer+2] = base(instruct.l, basePointer);
        stack[*stackPointer+3] = *basePointer;
        stack[*stackPointer+4] = *programCounter+1;
        *basePointer = *stackPointer+1;
        printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
        *programCounter = instruct.m;
        break;

    /*Increment sp by M, INC*/
    case 6:
        instructionName = "INC";
        *stackPointer = *stackPointer+ (instruct.m);
        printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
        *programCounter += 1;
        break;

    /*Jump to instruction M, JMP*/
    case 7:
        instructionName = "JMP";
        printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
        *programCounter = instruct.m;
        break;

    /*Jump to instruction M if top stack element is 0, JPC*/
    case 8:
        instructionName = "JPC";
        if(stack[*stackPointer] == 0)
        {
            *stackPointer -= 1;
            printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
            *programCounter = instruct.m;
        }
        else
        {
            *stackPointer -= 1;
            printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
            *programCounter += 1;
        }
        break;

    /*Performs different input/output functions or halts the system based on the M, SIO*/
    case 9:
        instructionName = "SIO";

        /*Writes the top stack element to the screen, SIO*/
        if(instruct.m == 1)
        {
            printf("%d", stack[*stackPointer]);
            *stackPointer -= 1;
            printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
            *programCounter += 1;
            break;
        }
         /*Read in input from user and store it at the top of the stack, SIO*/
        else if(instruct.m == 2)
        {
            *stackPointer += 1;
            int x;
            scanf("%d", &x);
            stack[*stackPointer] = x;
            printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
            *programCounter += 1;
            break;
        }
        /*Halt the machine, SIO*/
        else if(instruct.m == 3)
        {
            //fprintf(fWrite, "%d %s %d %d\n", *programCounter, instructionName, instruct.l, instruct.m);
            //fprintf(fWrite, "SUCCESSFULLY HALTED");
            fprintf(fWrite, "%d\t%s\t%d\t%d\t0\t0\t0\t", *programCounter, instructionName, instruct.l, instruct.m);
            *halt = 1;
            break;
        }
    }
}

/*Method to interpret OPR commands, mainly here to enhance readability of InterpretOp*/
void InterpretOPR(instruction instruct, int* basePointer, int* stackPointer, int* programCounter, int* currentLevel,
                 int *lexiLevel, FILE* fWrite)
{
    int pc = *programCounter;
    pc = pc+1;
    char* instructionName= "OPR";
    int x;
    int y;

    switch(instruct.m)
            {
            /*RET*/
            case 0:
                *stackPointer = *basePointer-1;
                *basePointer = stack[*stackPointer+3];
                //If returning, reduce the lexi level by one and remove the position from the array.
                *currentLevel = *currentLevel-1;
                lexiLevel[*currentLevel] = -1;
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &stack[*stackPointer+4], currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter = stack[*stackPointer+4];
                break;

            /*NEG*/
            case 1:
                stack[*stackPointer] = 0 - stack[*stackPointer];
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;


            /*ADD*/
            case 2:
                *stackPointer -= 1;
                stack[*stackPointer] = stack[*stackPointer]+stack[*stackPointer+1];
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*SUB*/
            case 3:
                *stackPointer -= 1;
                stack[*stackPointer] = stack[*stackPointer]-stack[*stackPointer+1];
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*MUL*/
            case 4:
                *stackPointer -= 1;
                stack[*stackPointer] = stack[*stackPointer]*stack[*stackPointer+1];
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*DIV*/
            case 5:
                *stackPointer -= 1;
                stack[*stackPointer] = stack[*stackPointer]/stack[*stackPointer+1];
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*ODD*/
            case 6:
                stack[*stackPointer] = stack[*stackPointer]%2;
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*MOD*/
            case 7:
                *stackPointer -= 1;
                stack[*stackPointer] = stack[*stackPointer]%stack[*stackPointer+1];
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*EQL*/
            case 8:
                *stackPointer -= 1;
                x = stack[*stackPointer];
                y = stack[*stackPointer+1];
                if(x == y)
                {
                    stack[*stackPointer] = 1;
                }
                else
                {
                    stack[*stackPointer] = 0;
                }
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*NEQ*/
            case 9:
                 *stackPointer -= 1;
                x = stack[*stackPointer];
                y = stack[*stackPointer+1];
                if(x != y)
                {
                    stack[*stackPointer] = 1;
                }
                else
                {
                    stack[*stackPointer] = 0;
                }
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*LSS*/
            case 10:
                 *stackPointer -= 1;
                x = stack[*stackPointer];
                y = stack[*stackPointer+1];
                if(x < y)
                {
                    stack[*stackPointer] = 1;
                }
                else
                {
                    stack[*stackPointer] = 0;
                }
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*LEQ*/
            case 11:
                *stackPointer -= 1;
                x = stack[*stackPointer];
                y = stack[*stackPointer+1];
                if(x > y)
                {
                    stack[*stackPointer] = 1;
                }
                else
                {
                    stack[*stackPointer] = 0;
                }
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*GTR*/
            case 12:
                *stackPointer -= 1;
                x = stack[*stackPointer];
                y = stack[*stackPointer+1];
                if(x > y)
                {
                    stack[*stackPointer] = 1;
                }
                else
                {
                    stack[*stackPointer] = 0;
                }
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;

            /*GEQ*/
            case 13:
                *stackPointer -= 1;
                x = stack[*stackPointer];
                y = stack[*stackPointer+1];
                if(x >= y)
                {
                    stack[*stackPointer] = 1;
                }
                else
                {
                    stack[*stackPointer] = 0;
                }
                printStack(instructionName, fWrite, basePointer, stackPointer, programCounter, &pc, currentLevel, lexiLevel, instruct.l, instruct.m);
                *programCounter += 1;
                break;
            }
}

/*Method to print out first part of stack trace*/
void printInterpreted(instruction *code, FILE* fWrite, int codeLength)
{
    int i;

    fprintf(fWrite, "Line\tOP\tL\tM\n");

    for(i = 0; i < codeLength; i++)
    {
        switch(code[i].op)
        {
        /*LIT*/
        case 1:
            fprintf(fWrite,"%d\tLIT\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*OPR*/
        case 2:
            switch(code[i].m)
            {
            /*RET*/
            case 0:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (RET)\n", i, code[i].l, code[i].m);
                break;

            /*NEG*/
            case 1:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (NEG)\n", i, code[i].l, code[i].m);
                break;

            /*ADD*/
            case 2:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (ADD)\n", i, code[i].l, code[i].m);
                break;

            /*SUB*/
            case 3:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (SUB)\n", i, code[i].l, code[i].m);
                break;

            /*MUL*/
            case 4:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (MUL)\n", i, code[i].l, code[i].m);
                break;

            /*DIV*/
            case 5:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (DIV)\n", i, code[i].l, code[i].m);
                break;

            /*ODD*/
            case 6:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (ODD)\n", i, code[i].l, code[i].m);
                break;

            /*MOD*/
            case 7:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (MOD)\n", i, code[i].l, code[i].m);
                break;

            /*EQL*/
            case 8:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (EQL)\n", i, code[i].l, code[i].m);
                break;

            /*NEQ*/
            case 9:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (NEQ)\n", i, code[i].l, code[i].m);
                break;

            /*LSS*/
            case 10:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (LSS)\n", i, code[i].l, code[i].m);
                break;

            /*LEQ*/
            case 11:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (LEQ)\n", i, code[i].l, code[i].m);
                break;

            /*GTR*/
            case 12:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (GTR)\n", i, code[i].l, code[i].m);
                break;

            /*GEQ*/
            case 13:
                fprintf(fWrite,"%d\tOPR\t%d\t%d (GEQ)\n", i, code[i].l, code[i].m);
                break;
            }
            break;

        /*LOD*/
        case 3:
            fprintf(fWrite,"%d\tLOD\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*STO*/
        case 4:
            fprintf(fWrite,"%d\tSTO\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*CAL*/
        case 5:
            fprintf(fWrite,"%d\tCAL\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*INC*/
        case 6:
            fprintf(fWrite,"%d\tINC\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*JMP*/
        case 7:
            fprintf(fWrite,"%d\tJMP\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*JPC*/
        case 8:
            fprintf(fWrite,"%d\tJPC\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*SIO*/
        case 9:
            fprintf(fWrite,"%d\tSIO\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*SIO*/
        case 10:
            fprintf(fWrite,"%d\tSIO\t%d\t%d\n", i, code[i].l, code[i].m);
            break;

        /*SIO*/
        case 11:
            fprintf(fWrite,"%d\tSIO\t%d\t%d\n", i, code[i].l, code[i].m);
           break;

        }
    }

    fprintf(fWrite, "\n");
}

/*Method to print out second part of stack trace*/
void printStack(char* instruct, FILE* fWrite, int* basePointer, int* stackPointer, int* oldProgramCounter, int* newProgramCounter, int* currentLevel, int* lexiLevel,
                 int l, int m)
{
    fprintf(fWrite, "%d\t%s\t%d\t%d\t%d\t%d\t%d\t", *oldProgramCounter, instruct, l, m, *newProgramCounter, *basePointer, *stackPointer);

    int temp = *stackPointer;
    //If a call instruction, make sure to print the additional 4 spots for the activation record
    if(strcmp(instruct, "CAL")==0)
    {
        temp = temp+4;
    }
    int i;
    int j;

    for(i = 1; i < temp+1; i++)
    {
        fprintf(fWrite, "%d ", stack[i]);
        //Check if we need to print out brackets where necessary for activation records
        for(j = 0; j < *currentLevel; j++)
        {
            int compareLevel = lexiLevel[j];
            if(compareLevel == i)
                fprintf(fWrite, "| ");
        }
    }
    fprintf(fWrite,"\n");
}

/*Method to find a variable L levels down*/
int base(int l, int* basePointer)
{
    int b1;
    b1 = *basePointer;
        while (l > 0)
         {
         b1 = stack[b1 + 1];
         l--;
         }
    return b1;
}
