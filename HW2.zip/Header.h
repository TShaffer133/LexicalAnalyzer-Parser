#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Constants
#define MAX_STACK_HEIGHT 2000
#define MAX_SYMBOL_TABLE_SIZE 2000
#define MAX_CODE_LENGTH 500
#define MAX_LEXI_LEVELS 3
#define identMax 11
#define numMax 10
#define MAX_NUMBER_LENGTH 5

#ifndef GLB
#define GLB

//Files
FILE *fileCode;
FILE *fileCleanCode;
FILE *fileLexTable;
FILE *fileLexTableList;
FILE *fileMCode;
FILE *fileTrace;

char inputFileName[999];
int procedures[999][2], procPos = 0; //0=level 1= line

typedef enum{
	nulsym = 1, identsym = 2, numbersym = 3, plussym = 4,
    minussym = 5, multsym = 6, slashsym = 7, oddsym = 8, eqlsym = 9,
    neqsym = 10, lessym = 11, leqsym = 12, gtrsym = 13, geqsym = 14,
    lparentsym = 15, rparentsym = 16, commasym = 17, semicolonsym = 18,
    periodsym = 19, becomesym = 20, beginsym = 21, endsym = 22, ifsym = 23,
    thensym = 24, whilesym = 25, dosym = 26, callsym = 27, constsym = 28,
    varsym = 29, procsym = 30, writesym = 31, readsym = 32, elsesym = 32, errsym = 33,
    newlinesym = 34
} token_type;

typedef struct symbol {
    int kind; // const = 1, var = 2, proc = 3
    char name[12]; // name up to 11 chars
    int val; // number (ASCII value)
    int level; // L level
    int addr; // M address
} symTable;

//Struct
typedef struct instr{
	int op; //For constants, you must store kind, name and value.
	int l; //For variables, you must store kind, name, L and M.
	int m; //For procedures, you must store kind, name, L and M.
} instruction;

//Lex table
typedef struct tokens{
    int type;
    char name[identMax];
} Token;

Token tokenList[MAX_CODE_LENGTH];

#endif // GLB
