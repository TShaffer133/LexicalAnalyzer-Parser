Problems:

Does not output executable machine code.
Does not properly handle constant declarations.

To use, compile the Compiler and enter as arguments a number between (0, 3) depending on how many console commands you would like to input.

e.g. ./Compiler 3 -l -a -v
     ./Compiler 1 -v
     ./Compiler 

lexicalAnalyzer outputs three files, of which the lexemeList is the one that is read in by the Parser.

The Parser reads in lexemeList.txt and outputs psasm.txt

The VM machine reads in psasm.txt and outputs a stacktrace.txt that details all the steps taken.

While the VM machine is fully functional, the parser does not work for all operations and can output faulty machine code.