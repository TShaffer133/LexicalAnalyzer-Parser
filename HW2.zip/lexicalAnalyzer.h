#include "Header.h"
#include <ctype.h>

/* number of reserved words */
#define norw 15

/* maximum integer value */
#define imax 32767

/* maximum number of chars for idents */
#define cmax 11

/* maximum depth of block nesting */
#define nestmax 5

/* maximum length of strings */
#define strmax 256

/* list of reserved word names */
char *word [norw] =
{ "null", "begin", "call", "const", "do",
  "else", "end", "if", "odd", "procedure",
  "read", "then", "var", "while", "write"};

/*Function Prototypes*/
char readLongComments(FILE* input, char ch);
char isSpecial(FILE* input, FILE* cInput, FILE* lexTable, FILE* lexList, char ch);
char isAlpha(FILE* input, FILE* cInput, FILE* lexTable, FILE* lexList, char ch);

int scan(int flag)
{
    FILE* input;
    FILE* cInput;
    FILE* lexTable;
    FILE* lexList;

    input = fopen("in.txt", "r");
        if(input == NULL)
        {
            printf("Input File not found.");
            exit(0);
        }
    cInput = fopen("cleaninput.txt", "w");
    lexTable = fopen("lexemetable.txt", "w");
    lexList = fopen("lexemelist.txt", "w");

    fprintf(lexTable, "lexeme\t\ttoken type\n");

    char ch = fgetc(input);
    int checker;
    while(ch != EOF)
    {
        int checker = ch + '0';
        /*If it's a comment, ignore it*/
        if(ch == '/')
        {
            ch = fgetc(input);
            if ( ch == '*')
            {
                ch = fgetc(input);
                ch = readLongComments(input, ch);
            }
        }
        /*If the character is a special token*/
        else if(ispunct(ch))
        {
            ch = isSpecial(input, cInput, lexTable, lexList, ch);
        }
        /*Else if it is a special token*/
        else if (isalpha(ch))
        {
            ch = isAlpha(input, cInput, lexTable, lexList, ch);
        }
        /*Else if it is a digit*/
        else if (isdigit(ch))
        {
            /*Checker will tally how many digits are in the number*/
            checker = 0;
            fprintf(lexList, "3 ", ch);
            /*Keep reading in digits*/
            while(isdigit(ch))
            {
                fprintf(cInput, "%c", ch);
                fprintf(lexTable, "%c", ch);
                fprintf(lexList, "%c", ch);
                checker = checker + 1;
                ch = fgetc(input);
                /*Checks if someone tried to make a variable start with a number*/
                if(isalpha(ch))
                {
                    printf("Cannot start a variable name with a number!");
                    exit(0);
                }
            }
            /*Once the number has been read in, output an error message if the checker number is larger than 0 and exit the process*/
            if(checker > 5)
            {
                printf("Number received larger than 5 digits, cannot process!");
                exit(0);
            }
            else
            {
                fprintf(lexTable, "\t\t3\n", ch);
                fprintf(lexList, " ");
            }

        }
        /*Else if it is a space*/
        else if(isspace(ch))
        {
            fprintf(cInput, "%c", ch);
            ch = fgetc(input);
        }
        /*Else if it a control token*/
        else if(iscntrl(ch))
        {
            fprintf(cInput, "%c", ch);
            ch = fgetc(input);
        }
        /*Otherwise print it out to clean input*/
        else
        {
            fprintf(cInput, "%c", ch);
        }
    }

    if(flag)
    {
        char c;
            printf("\nGenerated lexeme table\n");
            c = fgetc(lexTable);
            while(c != EOF){
                printf("%c",c);
                c = fgetc(lexTable);
            }
            printf("\n\n");
    }

    fclose(input);
    fclose(cInput);
    fclose(lexTable);
    fclose(lexList);
    return 1;
}

/*Function to read in long comments and terminates upon comment terminating condition*/
char readLongComments(FILE* input, char ch)
{
    while(ch != '*')
    {
        ch = fgetc(input);
    }

    if(fgetc(input) != '/')
    {
        ch = fgetc(input);
        readLongComments(input, ch);
    }

    /*If it has terminated on /, get the next char after / */
    ch = fgetc(input);
    return ch;
}

/*Checks what type of specialChar it is and performs the appropriate operation*/
char isSpecial(FILE* input, FILE* cInput, FILE* lexTable, FILE* lexList, char ch)
{
    switch(ch)
    {
    case '+':
        fprintf(cInput, "+");
        fprintf(lexTable, "+\t\t4\n");
        fprintf(lexList, "4 ");
        ch = fgetc(input);
        return ch;
    case '-':
        fprintf(cInput, "-");
        fprintf(lexTable, "-\t\t5\n");
        fprintf(lexList, "5 ");
        ch = fgetc(input);
        return ch;
    case '*':
        fprintf(cInput, "*");
        fprintf(lexTable, "*\t\t6\n");
        fprintf(lexList, "6 ");
        ch = fgetc(input);
        return ch;
    case '/':
        fprintf(cInput, "/");
        fprintf(lexTable, "/\t\t7\n");
        fprintf(lexList, "7 ");
        ch = fgetc(input);
        return ch;
    case '(':
        fprintf(cInput, "(");
        fprintf(lexTable, "(\t\t15\n");
        fprintf(lexList, "15 ");
        ch = fgetc(input);
        return ch;
    case ')':
        fprintf(cInput, ")");
        fprintf(lexTable, ")\t\t16\n");
        fprintf(lexList, "16 ");
        ch = fgetc(input);
        return ch;
    case '=':
        fprintf(cInput, "=");
        fprintf(lexTable, "=\t\t9\n");
        fprintf(lexList, "9 ");
        ch = fgetc(input);
        return ch;
    case ',':
        fprintf(cInput, ",");
        fprintf(lexTable, ",\t\t17\n");
        fprintf(lexList, "17 ");
        ch = fgetc(input);
        return ch;
    case '.':
        fprintf(cInput, ".");
        fprintf(lexTable, ".\t\t19\n");
        fprintf(lexList, "19 ");
        ch = fgetc(input);
        return ch;
    case '<':
        fprintf(cInput, "<");
        fprintf(lexTable, "<\t\t11\n");
        fprintf(lexList, "11 ");
        ch = fgetc(input);
        return ch;
    case '>':
        fprintf(cInput, ">");
        fprintf(lexTable, ">\t\t13\n");
        fprintf(lexList, "13 ");
        ch = fgetc(input);
        return ch;
    case ';':
        fprintf(cInput, ";");
        fprintf(lexTable, ";\t\t18\n");
        fprintf(lexList, "18 ");
        ch = fgetc(input);
        return ch;
    case ':':
       ch = fgetc(input);
       if(ch != '=')
       {
           printf("Error: Expected '=' after ':'. No assignment.\n");
           ch = fgetc(input);
           return ch;
       }
       else
       {
            fprintf(cInput, ":=");
            fprintf(lexTable, ":=\t\t20\n");
            fprintf(lexList, "20 ");
            ch = fgetc(input);
            return ch;
       }

    default:
        printf("Error: Invalid special symbol.\n");
        exit(0);
    }
}

char isAlpha(FILE* input, FILE* cInput, FILE* lexTable, FILE* lexList, char ch)
{
    char name[11];
    name[0] = ch;
    ch = fgetc(input);
    int i = 1;
    int compare;

    if(isalpha(ch)|| isdigit(ch))
    {
        /*Scan the rest of the possible identifier, if it exists*/
        while(isalpha(ch)|| isdigit(ch))
        {
            /*If the identifier is less than or equal to 11 characters, store it*/
            if(i < 11)
            {
                name[i] = ch;
                ch = fgetc(input);
                i = i + 1;
                name[i+1] = '\0';
            }
            /*Otherwise print error message*/
            else
            {
                printf("Cannot have identifier longer than 11 characters!\n");
                exit(0);
            }
        }
    }
    else
    {
        name[i] = '\0';
    }

    /*With the fully obtained string, start comparing it to reserved words*/
    for(i = 0; i < norw; i++)
    {
        compare = strcmp(name, word[i]);
        /*If a match has been found, exit loop*/
        if(compare == 0)
        {
            compare = i;
            break;
        }
        /*Otherwise, name is an identifier and needs to be checked against the list of other identifiers*/
        else
        {
            compare = -1;
        }
    }

    /*Determine the course of action to take depending on what word the name is*/
    switch(compare)
    {
        case 0:
            fprintf(cInput, "null");
            fprintf(lexTable, "null\t\t1\n");
            fprintf(lexList, "1 ");
            return ch;

        case 1:
            fprintf(cInput, "begin");
            fprintf(lexTable, "begin\t\t21\n");
            fprintf(lexList, "21 ");
            return ch;

        case 2:
            fprintf(cInput, "call" );
            fprintf(lexTable, "call\t\t27\n");
            fprintf(lexList, "27 ");
            return ch;

        case 3:
            fprintf(cInput, "const");
            fprintf(lexTable, "const\t\t28\n");
            fprintf(lexList, "28 ");
            return ch;

        case 4:
            fprintf(cInput, "do");
            fprintf(lexTable, "do\t\t1\26");
            fprintf(lexList, "26 ");
            return ch;

        case 5:
            fprintf(cInput, "else");
            fprintf(lexTable, "else\t\t33\n");
            fprintf(lexList, "33 ");
            return ch;

        case 6:
            fprintf(cInput, "end");
            fprintf(lexTable, "end\t\t22\n");
            fprintf(lexList, "22 ");
            return ch;

        case 7:
            fprintf(cInput, "if");
            fprintf(lexTable, "if\t\t23\n");
            fprintf(lexList, "23 ");
            return ch;

        case 8:
            fprintf(cInput, "odd");
            fprintf(lexTable, "odd\t\t8\n");
            fprintf(lexList, "8 ");
            return ch;

        case 9:
            fprintf(cInput, "procedure");
            fprintf(lexTable, "procedure\t\t30\n");
            fprintf(lexList, "30 ");
            return ch;

        case 10:
            fprintf(cInput, "read");
            fprintf(lexTable, "read\t\t32\n");
            fprintf(lexList, "32 ");
            return ch;

        case 11:
            fprintf(cInput, "then");
            fprintf(lexTable, "then\t\t24\n");
            fprintf(lexList, "24 ");
            return ch;

        case 12:
            fprintf(cInput, "var");
            fprintf(lexTable, "var\t\t29\n");
            fprintf(lexList, "29 ");
            return ch;

        case 13:
            fprintf(cInput, "while");
            fprintf(lexTable, "while\t\t25\n");
            fprintf(lexList, "25 ");
            return ch;

        case 14:
            fprintf(cInput, "write");
            fprintf(lexTable, "write\t\t31\n");
            fprintf(lexList, "31 ");
            return ch;

        case -1:
            fprintf(cInput, "%s", name);
            fprintf(lexTable, "%s\t\t2\n", name);
            fprintf(lexList, "2 %s ", name);
            if(ispunct(ch))
            {
                 ch = isSpecial(input, cInput, lexTable, lexList, ch);
                 return ch;
            }
            else
            {
                return ch;
            }

        default:
                printf("Something strange happened with the identifiers.");
    }


}


