#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

/* number of reserved words */
#define norw 15

/*Max possible table size*/
#define	MAX_SYMBOL_TABLE_SIZE 100

/* maximum integer value */
#define imax 32767

/* maximum number of chars for idents */
#define cmax 11

/* maximum depth of block nesting */
#define nestmax 5

/* maximum length of strings */
#define strmax 256

#define MAX_CODE_LENGTH 500

/*Enumeration dictionary for the different token types*/
typedef	enum
{
    nulsym	=	1,
    identsym,	numbersym,	plussym,
    minussym,	multsym,	slashsym,
    oddsym,	eqsym,	neqsym,
    lessym,	leqsym,	gtrsym,
    geqsym,	lparentsym,	rparentsym,
    commasym,	semicolonsym,	periodsym,
    becomessym,	beginsym, endsym,
    ifsym,	thensym, whilesym,
    dosym,	callsym, constsym,
    varsym,	procsym, writesym,
    readsym	, elsesym
}	token_type;

typedef struct symbol
{
    int kind; /*const = 1, var = 2, proc = 3*/
    char* name;
    int val; /*ASCII value*/
    int level; /*Lexical level*/
    int addr; /*M address*/
} symbol;

/*Global symbol table for ease of use*/
symbol symbol_table[MAX_SYMBOL_TABLE_SIZE];

/*Function prototypes*/
char* block(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int codeCounter, int lexiLevel);
char* statement(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel);
char* condition(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel);
char* expression(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel);
char* term(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel);
char* factor(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel);
void emit(FILE* error, FILE* mCode, int codeCounter, int op, int l, int m);
void readToken(FILE* input, FILE* error, char* token);

int main()
{

    FILE* input;
    FILE* mCode;
    FILE* error;

    input = fopen("lexemelist.txt", "r");
    mCode = fopen("mcode.txt", "w");
    error = fopen("syntaxcheck.txt", "w");

    int symbolCounter = 0;
    int codeCounter = 0;
    int lexiLevel = 0;

    char* token = malloc(sizeof(char)*12);
    readToken(input, error, token);

    /*Parses through block of code*/
    token = block(input, mCode, error, token, symbolCounter, codeCounter, lexiLevel);

    readToken(input, error, token);
    int tokenValue = atoi(token);
    /*Checks if period is at the end*/
    if (tokenValue!= periodsym)
    {
        fprintf(error, "Error: No period at end of block");
        exit(0);
    }
    fprintf(error, "Program is syntactically correct.");
    free(token);
    return 1;
}

/*Function to parse through blocks*/
char* block(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int codeCounter, int lexiLevel)
{
    char numVal[100];
    int i = 1;
    int tokenValue = atoi(token);
    switch(tokenValue)
    {
    case constsym:
        symbol_table[symbolCounter].kind = 1;
        while(tokenValue != commasym)
        {
            readToken(input, error, token);
            tokenValue = atoi(token);
            if (tokenValue != identsym)
            {
                fprintf(error, "Error: Expected identifier after constant declaration.");
                exit(0);
            }

            /*Reads in the name of the identifier and stores it in the symbol table*/
            readToken(input, error, token);
            readToken(input, error, token);
            tokenValue = atoi(token);

            /*Check if there is an equal sign*/
            readToken(input, error, token);
            tokenValue = atoi(token);
            if (tokenValue != eqsym)
            {
                fprintf(error, "Error: Expected = after identifier declaration.");
                exit(0);
            }

            /*Check if const was assigned a numeric value*/
            readToken(input, error, token);
            tokenValue = atoi(token);
            if (isdigit(tokenValue) == 0)
            {
                fprintf(error, "Error: Expected numeric value for constants.");
                exit(0);
            }
            /*If so, read in the entire value*/
            else
            {
                 if(tokenValue > imax)
                    {
                        fprintf(error, "Error: Numeric value greater than 32767.");
                        exit(0);
                    }
                    else
                    {
                        symbol_table[symbolCounter].val = tokenValue;
                    }
            }
        }

        symbol_table[symbolCounter].level = lexiLevel;
        /*Check if semicolon is at end of statement*/
        readToken(input, error, token);
        tokenValue = atoi(token);
        if(tokenValue != semicolonsym)
        {
            fprintf(error, "Error: Expected ; after constant declaration.");
            exit(0);
        }
        /*Increase symbolCounter by 1*/
        symbolCounter +=1;
        break;

    case varsym:
         symbol_table[symbolCounter].kind = 2;

         while(tokenValue != commasym)
         {
            readToken(input, error, token);
            tokenValue = atoi(token);
             if (tokenValue != identsym)
            {
                fprintf(error, "Error: Expected identifier after variable declaration.");
                exit(0);
            }

            /*Reads in the name of the identifier and stores it in the symbol table*/
            readToken(input, error, token);
            readToken(input, error, token);
            tokenValue = atoi(token);
         }
         symbol_table[symbolCounter].level = lexiLevel;
        /*Check if semicolon is at end of statement*/
        readToken(input, error, token);
        tokenValue = atoi(token);
        if(tokenValue != semicolonsym)
        {
            fprintf(error, "Error: Expected ; after variable declaration.");
            exit(0);
        }
        /*Increase symbolCounter by 1*/
        symbolCounter +=1;
         break;


    case procsym:
         symbol_table[symbolCounter].kind = 3;
            readToken(input, error, token);
            tokenValue = atoi(token);
            if (tokenValue != identsym)
            {
                fprintf(error, "Error: Expected identifier after procedure declaration.");
                exit(0);
            }
            /*Reads in the name of the identifier and stores it in the symbol table*/
            readToken(input, error, token);
            readToken(input, error, token);
            tokenValue = atoi(token);
            symbol_table[symbolCounter].level = lexiLevel;

        /*Check if semicolon is at end of statement*/
        readToken(input, error, token);
        tokenValue = atoi(token);
        if(tokenValue != semicolonsym)
        {
            fprintf(error, "Error: Expected ; after procedure declaration.");
            exit(0);
        }
        readToken(input, error, token);
        tokenValue = atoi(token);
        token = block(input, mCode, error, token, symbolCounter, codeCounter, lexiLevel);
        /*Increase symbolCounter by 1*/
        symbolCounter +=1;
        break;
    }
    token = statement(input, mCode, error, token, symbolCounter, lexiLevel);
    printf("%c", token);
    return token;

}

char* statement(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel)
{
    int tokenValue;
    readToken(input, error, token);
    tokenValue = atoi(token);

    switch(tokenValue)
    {
    /*Identsym case*/
    case identsym:
        readToken(input, error, token);
        tokenValue = atoi(token);
        if(tokenValue != becomessym)
        {
            fprintf(error, "Error: expected become after identifier");
            exit(0);
        }
        readToken(input, error, token);
        tokenValue = atoi(token);
        token = expression(input, mCode, error, token, symbolCounter, lexiLevel);
        break;

    /*Callsym case*/
    case callsym:
        lexiLevel += 1;
        readToken(input, error, token);
        tokenValue = atoi(token);
        if(tokenValue != identsym)
        {
            fprintf(error, "Error: identifier expected after call");
            exit(0);
        }
        readToken(input, error, token);
        tokenValue = atoi(token);
        break;

    /*Beginsym case*/
    case beginsym:
        readToken(input, error, token);
        tokenValue = atoi(token);
        /*Increase lexigraphic level by one*/
        lexiLevel += 1;
        /*While in the begin statement, keep going until semicolon is reached*/
        while(tokenValue != semicolonsym)
        {
            readToken(input, error, token);
            tokenValue = atoi(token);
            token = statement(input, mCode, error, token, symbolCounter, lexiLevel);
        }
        lexiLevel -= 1;
        if(tokenValue != endsym)
        {
            fprintf(error, "Error: Expected end statement");
            exit(0);
        }
        readToken(input, error, token);
        tokenValue = atoi(token);
        break;

    case ifsym:
        readToken(input, error, token);
        tokenValue = atoi(token);
        token = condition(input, mCode, error, token, symbolCounter,lexiLevel);
        if(tokenValue != thensym)
        {
            fprintf(error, "Error: Expected then statement");
            exit(0);
        }
        readToken(input, error, token);
        tokenValue = atoi(token);
        token = statement(input, mCode, error, token, symbolCounter, lexiLevel);
        break;

    case whilesym:
        readToken(input, error, token);
        tokenValue = atoi(token);
        lexiLevel += 1;
        token = condition(input, mCode, error, token, symbolCounter, lexiLevel);
        if(tokenValue != dosym)
        {
            readToken(input, error, token);
            tokenValue = atoi(token);
        token = statement(input, mCode, error, token, symbolCounter, lexiLevel);
        }
        lexiLevel -= 1;
        break;
    }
    return token;
}

char* condition(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel)
{
    int tokenValue;
    readToken(input, error, token);
    tokenValue = atoi(token);

    if (tokenValue == oddsym)
    {
        readToken(input, error, token);
        tokenValue = atoi(token);
        token = expression(input, mCode, error, token, symbolCounter, lexiLevel);
    }
    else
    {
        token = expression(input, mCode, error, token, symbolCounter, lexiLevel);
        if(tokenValue < 9 || tokenValue > 14)
        {
            fprintf(error, "Error: Expected a relation in condition statement");
            exit(0);
        }
        readToken(input, error, token);
        tokenValue = atoi(token);
        token = expression(input, mCode, error, token, symbolCounter, lexiLevel);
    }
    return token;
}

char* expression(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel)
{
    int tokenValue;
    readToken(input, error, token);
    tokenValue = atoi(token);
    if(tokenValue == plussym || tokenValue == minussym)
    {
        readToken(input, error, token);
        tokenValue = atoi(token);
    }
    token = term(input, mCode, error, token, symbolCounter, lexiLevel);
        while(tokenValue == plussym || tokenValue == minussym)
        {
            readToken(input, error, token);
            tokenValue = atoi(token);
            token = term(input, mCode, error, token, symbolCounter, lexiLevel);
        }
        return token;
}

char* term(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel)
{
    int tokenValue;
    readToken(input, error, token);
    tokenValue = atoi(token);
    token = factor(input, mCode, error, token, symbolCounter, lexiLevel);

    while(tokenValue == multsym || tokenValue == slashsym)
    {
        readToken(input, error, token);
        tokenValue = atoi(token);
        token = factor(input, mCode, error, token, symbolCounter, lexiLevel);
    }
}

char* factor(FILE* input, FILE* mCode, FILE* error, char* token, int symbolCounter, int lexiLevel)
{
    int tokenValue;
    readToken(input, error, token);
    tokenValue = atoi(token);

    if(tokenValue == identsym)
    {
        readToken(input, error, token);
        tokenValue = atoi(token);
    }
    else if (isdigit(tokenValue)!= 0)
    {
        readToken(input, error, token);
        tokenValue = atoi(token);
    }
    else if (tokenValue == lparentsym)
    {
        readToken(input, error, token);
        tokenValue = atoi(token);
        token = expression(input, mCode, error, token, symbolCounter, lexiLevel);
        tokenValue = atoi(token);
        if(tokenValue != rparentsym)
        {
            fprintf(error, "Error: Expected right parenthesis");
            exit(0);
        }
    }
    else
    {
        fprintf(error, "Error: Unknown symbol in math expression");
        exit(0);
    }
}
/*Function to produce machine code from parsed tokens*/
void emit(FILE* error, FILE* mCode, int codeCounter, int op, int l, int m)
{
    if(codeCounter > MAX_CODE_LENGTH)
    {
        fprintf(error, "Error: Code length exceeds 500.");
    }
    else
    {
        fprintf(mCode, "%d %d %d ", op, l, m);
    }
}

void readToken(FILE* input, FILE* error, char* token)
{
    fscanf(input, "%s", token);
}
