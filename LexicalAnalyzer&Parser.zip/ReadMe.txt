Worked on by Tyrone Shaffer

*** Problems ***

Does not properly parse through lexeme list.
Does not generate intermediate code.

How to use:

First, use the lexical analyzer to process your code, written in a text file that must be named input.txt. It will then output a lexemelist,
which will be used by the Parser as input to attempt to check if there are any syntactical errors in the code.

Unfortunately, it does not create intermediate code and therefore cannot run a V/N machine, although the attached V/M machine can run machine
code written in a text file labeled mcode.txt. 
